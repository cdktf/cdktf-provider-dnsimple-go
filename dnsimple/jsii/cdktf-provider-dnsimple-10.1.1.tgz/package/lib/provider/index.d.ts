/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DnsimpleProviderConfig {
    /**
    * The account for API operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs#account DnsimpleProvider#account}
    */
    readonly account?: string;
    /**
    * Flag to enable the prefetch of zone records.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs#prefetch DnsimpleProvider#prefetch}
    */
    readonly prefetch?: boolean | cdktf.IResolvable;
    /**
    * Flag to enable the sandbox API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs#sandbox DnsimpleProvider#sandbox}
    */
    readonly sandbox?: boolean | cdktf.IResolvable;
    /**
    * The API v2 token for API operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs#token DnsimpleProvider#token}
    */
    readonly token?: string;
    /**
    * Custom string to append to the user agent used for sending HTTP requests to the API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs#user_agent DnsimpleProvider#user_agent}
    */
    readonly userAgent?: string;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs#alias DnsimpleProvider#alias}
    */
    readonly alias?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs dnsimple}
*/
export declare class DnsimpleProvider extends cdktf.TerraformProvider {
    static readonly tfResourceType = "dnsimple";
    /**
    * Generates CDKTF code for importing a DnsimpleProvider resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DnsimpleProvider to import
    * @param importFromId The id of the existing DnsimpleProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DnsimpleProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs dnsimple} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DnsimpleProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DnsimpleProviderConfig);
    private _account?;
    get account(): string | undefined;
    set account(value: string | undefined);
    resetAccount(): void;
    get accountInput(): string | undefined;
    private _prefetch?;
    get prefetch(): boolean | cdktf.IResolvable | undefined;
    set prefetch(value: boolean | cdktf.IResolvable | undefined);
    resetPrefetch(): void;
    get prefetchInput(): boolean | cdktf.IResolvable | undefined;
    private _sandbox?;
    get sandbox(): boolean | cdktf.IResolvable | undefined;
    set sandbox(value: boolean | cdktf.IResolvable | undefined);
    resetSandbox(): void;
    get sandboxInput(): boolean | cdktf.IResolvable | undefined;
    private _token?;
    get token(): string | undefined;
    set token(value: string | undefined);
    resetToken(): void;
    get tokenInput(): string | undefined;
    private _userAgent?;
    get userAgent(): string | undefined;
    set userAgent(value: string | undefined);
    resetUserAgent(): void;
    get userAgentInput(): string | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
