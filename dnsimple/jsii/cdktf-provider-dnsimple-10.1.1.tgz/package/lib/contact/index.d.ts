/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ContactConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/contact#address1 Contact#address1}
    */
    readonly address1: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/contact#address2 Contact#address2}
    */
    readonly address2?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/contact#city Contact#city}
    */
    readonly city: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/contact#country Contact#country}
    */
    readonly country: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/contact#email Contact#email}
    */
    readonly email: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/contact#fax Contact#fax}
    */
    readonly fax?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/contact#first_name Contact#first_name}
    */
    readonly firstName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/contact#job_title Contact#job_title}
    */
    readonly jobTitle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/contact#label Contact#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/contact#last_name Contact#last_name}
    */
    readonly lastName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/contact#organization_name Contact#organization_name}
    */
    readonly organizationName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/contact#phone Contact#phone}
    */
    readonly phone: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/contact#postal_code Contact#postal_code}
    */
    readonly postalCode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/contact#state_province Contact#state_province}
    */
    readonly stateProvince: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/contact dnsimple_contact}
*/
export declare class Contact extends cdktf.TerraformResource {
    static readonly tfResourceType = "dnsimple_contact";
    /**
    * Generates CDKTF code for importing a Contact resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Contact to import
    * @param importFromId The id of the existing Contact that should be imported. Refer to the {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/contact#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Contact to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/contact dnsimple_contact} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ContactConfig
    */
    constructor(scope: Construct, id: string, config: ContactConfig);
    get accountId(): number;
    private _address1?;
    get address1(): string;
    set address1(value: string);
    get address1Input(): string | undefined;
    private _address2?;
    get address2(): string;
    set address2(value: string);
    resetAddress2(): void;
    get address2Input(): string | undefined;
    private _city?;
    get city(): string;
    set city(value: string);
    get cityInput(): string | undefined;
    private _country?;
    get country(): string;
    set country(value: string);
    get countryInput(): string | undefined;
    get createdAt(): string;
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
    private _fax?;
    get fax(): string;
    set fax(value: string);
    resetFax(): void;
    get faxInput(): string | undefined;
    get faxNormalized(): string;
    private _firstName?;
    get firstName(): string;
    set firstName(value: string);
    get firstNameInput(): string | undefined;
    get id(): number;
    private _jobTitle?;
    get jobTitle(): string;
    set jobTitle(value: string);
    resetJobTitle(): void;
    get jobTitleInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _lastName?;
    get lastName(): string;
    set lastName(value: string);
    get lastNameInput(): string | undefined;
    private _organizationName?;
    get organizationName(): string;
    set organizationName(value: string);
    resetOrganizationName(): void;
    get organizationNameInput(): string | undefined;
    private _phone?;
    get phone(): string;
    set phone(value: string);
    get phoneInput(): string | undefined;
    get phoneNormalized(): string;
    private _postalCode?;
    get postalCode(): string;
    set postalCode(value: string);
    get postalCodeInput(): string | undefined;
    private _stateProvince?;
    get stateProvince(): string;
    set stateProvince(value: string);
    get stateProvinceInput(): string | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
