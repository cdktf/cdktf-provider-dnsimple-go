/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataDnsimpleRegistrantChangeCheckConfig extends cdktf.TerraformMetaArguments {
    /**
    * DNSimple contact ID for which the registrant change check is being performed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/data-sources/registrant_change_check#contact_id DataDnsimpleRegistrantChangeCheck#contact_id}
    */
    readonly contactId: string;
    /**
    * DNSimple domain ID for which the registrant change check is being performed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/data-sources/registrant_change_check#domain_id DataDnsimpleRegistrantChangeCheck#domain_id}
    */
    readonly domainId: string;
}
export interface DataDnsimpleRegistrantChangeCheckExtendedAttributesOptions {
}
export declare function dataDnsimpleRegistrantChangeCheckExtendedAttributesOptionsToTerraform(struct?: DataDnsimpleRegistrantChangeCheckExtendedAttributesOptions): any;
export declare function dataDnsimpleRegistrantChangeCheckExtendedAttributesOptionsToHclTerraform(struct?: DataDnsimpleRegistrantChangeCheckExtendedAttributesOptions): any;
export declare class DataDnsimpleRegistrantChangeCheckExtendedAttributesOptionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDnsimpleRegistrantChangeCheckExtendedAttributesOptions | undefined;
    set internalValue(value: DataDnsimpleRegistrantChangeCheckExtendedAttributesOptions | undefined);
    get description(): string;
    get title(): string;
    get value(): string;
}
export declare class DataDnsimpleRegistrantChangeCheckExtendedAttributesOptionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDnsimpleRegistrantChangeCheckExtendedAttributesOptionsOutputReference;
}
export interface DataDnsimpleRegistrantChangeCheckExtendedAttributes {
}
export declare function dataDnsimpleRegistrantChangeCheckExtendedAttributesToTerraform(struct?: DataDnsimpleRegistrantChangeCheckExtendedAttributes): any;
export declare function dataDnsimpleRegistrantChangeCheckExtendedAttributesToHclTerraform(struct?: DataDnsimpleRegistrantChangeCheckExtendedAttributes): any;
export declare class DataDnsimpleRegistrantChangeCheckExtendedAttributesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDnsimpleRegistrantChangeCheckExtendedAttributes | undefined;
    set internalValue(value: DataDnsimpleRegistrantChangeCheckExtendedAttributes | undefined);
    get description(): string;
    get name(): string;
    private _options;
    get options(): DataDnsimpleRegistrantChangeCheckExtendedAttributesOptionsList;
    get required(): cdktf.IResolvable;
}
export declare class DataDnsimpleRegistrantChangeCheckExtendedAttributesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDnsimpleRegistrantChangeCheckExtendedAttributesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/data-sources/registrant_change_check dnsimple_registrant_change_check}
*/
export declare class DataDnsimpleRegistrantChangeCheck extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "dnsimple_registrant_change_check";
    /**
    * Generates CDKTF code for importing a DataDnsimpleRegistrantChangeCheck resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDnsimpleRegistrantChangeCheck to import
    * @param importFromId The id of the existing DataDnsimpleRegistrantChangeCheck that should be imported. Refer to the {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/data-sources/registrant_change_check#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDnsimpleRegistrantChangeCheck to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/data-sources/registrant_change_check dnsimple_registrant_change_check} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDnsimpleRegistrantChangeCheckConfig
    */
    constructor(scope: Construct, id: string, config: DataDnsimpleRegistrantChangeCheckConfig);
    private _contactId?;
    get contactId(): string;
    set contactId(value: string);
    get contactIdInput(): string | undefined;
    private _domainId?;
    get domainId(): string;
    set domainId(value: string);
    get domainIdInput(): string | undefined;
    private _extendedAttributes;
    get extendedAttributes(): DataDnsimpleRegistrantChangeCheckExtendedAttributesList;
    get id(): string;
    get registryOwnerChange(): cdktf.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
