/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface EmailForwardConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/email_forward#alias_name EmailForward#alias_name}
    */
    readonly aliasName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/email_forward#destination_email EmailForward#destination_email}
    */
    readonly destinationEmail: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/email_forward#domain EmailForward#domain}
    */
    readonly domain: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/email_forward dnsimple_email_forward}
*/
export declare class EmailForward extends cdktf.TerraformResource {
    static readonly tfResourceType = "dnsimple_email_forward";
    /**
    * Generates CDKTF code for importing a EmailForward resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EmailForward to import
    * @param importFromId The id of the existing EmailForward that should be imported. Refer to the {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/email_forward#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EmailForward to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/email_forward dnsimple_email_forward} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EmailForwardConfig
    */
    constructor(scope: Construct, id: string, config: EmailForwardConfig);
    get aliasEmail(): string;
    private _aliasName?;
    get aliasName(): string;
    set aliasName(value: string);
    get aliasNameInput(): string | undefined;
    private _destinationEmail?;
    get destinationEmail(): string;
    set destinationEmail(value: string);
    get destinationEmailInput(): string | undefined;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    get domainInput(): string | undefined;
    get id(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
