/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
export * as contact from './contact';
export * as domain from './domain';
export * as domainDelegation from './domain-delegation';
export * as dsRecord from './ds-record';
export * as emailForward from './email-forward';
export * as letsEncryptCertificate from './lets-encrypt-certificate';
export * as registeredDomain from './registered-domain';
export * as zone from './zone';
export * as zoneRecord from './zone-record';
export * as dataDnsimpleCertificate from './data-dnsimple-certificate';
export * as dataDnsimpleRegistrantChangeCheck from './data-dnsimple-registrant-change-check';
export * as dataDnsimpleZone from './data-dnsimple-zone';
export * as provider from './provider';
