/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataDnsimpleCertificateConfig extends cdktf.TerraformMetaArguments {
    /**
    * Certificate ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/data-sources/certificate#certificate_id DataDnsimpleCertificate#certificate_id}
    */
    readonly certificateId: number;
    /**
    * Domain name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/data-sources/certificate#domain DataDnsimpleCertificate#domain}
    */
    readonly domain: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/data-sources/certificate#timeouts DataDnsimpleCertificate#timeouts}
    */
    readonly timeouts?: DataDnsimpleCertificateTimeouts;
}
export interface DataDnsimpleCertificateTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/data-sources/certificate#read DataDnsimpleCertificate#read}
    */
    readonly read?: string;
}
export declare function dataDnsimpleCertificateTimeoutsToTerraform(struct?: DataDnsimpleCertificateTimeouts | cdktf.IResolvable): any;
export declare function dataDnsimpleCertificateTimeoutsToHclTerraform(struct?: DataDnsimpleCertificateTimeouts | cdktf.IResolvable): any;
export declare class DataDnsimpleCertificateTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDnsimpleCertificateTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DataDnsimpleCertificateTimeouts | cdktf.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/data-sources/certificate dnsimple_certificate}
*/
export declare class DataDnsimpleCertificate extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "dnsimple_certificate";
    /**
    * Generates CDKTF code for importing a DataDnsimpleCertificate resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDnsimpleCertificate to import
    * @param importFromId The id of the existing DataDnsimpleCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/data-sources/certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDnsimpleCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/data-sources/certificate dnsimple_certificate} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDnsimpleCertificateConfig
    */
    constructor(scope: Construct, id: string, config: DataDnsimpleCertificateConfig);
    get certificateChain(): string[];
    private _certificateId?;
    get certificateId(): number;
    set certificateId(value: number);
    get certificateIdInput(): number | undefined;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    get domainInput(): string | undefined;
    get id(): string;
    get privateKey(): string;
    get rootCertificate(): string;
    get serverCertificate(): string;
    private _timeouts;
    get timeouts(): DataDnsimpleCertificateTimeoutsOutputReference;
    putTimeouts(value: DataDnsimpleCertificateTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DataDnsimpleCertificateTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
