/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RegisteredDomainConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/registered_domain#auto_renew_enabled RegisteredDomain#auto_renew_enabled}
    */
    readonly autoRenewEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/registered_domain#contact_id RegisteredDomain#contact_id}
    */
    readonly contactId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/registered_domain#dnssec_enabled RegisteredDomain#dnssec_enabled}
    */
    readonly dnssecEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/registered_domain#extended_attributes RegisteredDomain#extended_attributes}
    */
    readonly extendedAttributes?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/registered_domain#name RegisteredDomain#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/registered_domain#premium_price RegisteredDomain#premium_price}
    */
    readonly premiumPrice?: string;
    /**
    * Timeouts for operations, given as a parsable string as in `10m` or `30s`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/registered_domain#timeouts RegisteredDomain#timeouts}
    */
    readonly timeouts?: RegisteredDomainTimeouts;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/registered_domain#transfer_lock_enabled RegisteredDomain#transfer_lock_enabled}
    */
    readonly transferLockEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/registered_domain#whois_privacy_enabled RegisteredDomain#whois_privacy_enabled}
    */
    readonly whoisPrivacyEnabled?: boolean | cdktf.IResolvable;
}
export interface RegisteredDomainDomainRegistration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/registered_domain#state RegisteredDomain#state}
    */
    readonly state?: string;
}
export declare function registeredDomainDomainRegistrationToTerraform(struct?: RegisteredDomainDomainRegistration): any;
export declare function registeredDomainDomainRegistrationToHclTerraform(struct?: RegisteredDomainDomainRegistration): any;
export declare class RegisteredDomainDomainRegistrationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RegisteredDomainDomainRegistration | undefined;
    set internalValue(value: RegisteredDomainDomainRegistration | undefined);
    get id(): number;
    get period(): number;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
}
export interface RegisteredDomainRegistrantChange {
    /**
    * State of the registrant change
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/registered_domain#state RegisteredDomain#state}
    */
    readonly state?: string;
}
export declare function registeredDomainRegistrantChangeToTerraform(struct?: RegisteredDomainRegistrantChange): any;
export declare function registeredDomainRegistrantChangeToHclTerraform(struct?: RegisteredDomainRegistrantChange): any;
export declare class RegisteredDomainRegistrantChangeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RegisteredDomainRegistrantChange | undefined;
    set internalValue(value: RegisteredDomainRegistrantChange | undefined);
    get accountId(): number;
    get contactId(): number;
    get domainId(): string;
    private _extendedAttributes;
    get extendedAttributes(): cdktf.StringMap;
    get id(): number;
    get irtLockLiftedBy(): string;
    get registryOwnerChange(): cdktf.IResolvable;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
}
export interface RegisteredDomainTimeouts {
    /**
    * Create timeout.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/registered_domain#create RegisteredDomain#create}
    */
    readonly create?: string;
    /**
    * Delete timeout (currently unused).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/registered_domain#delete RegisteredDomain#delete}
    */
    readonly delete?: string;
    /**
    * Update timeout.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/registered_domain#update RegisteredDomain#update}
    */
    readonly update?: string;
}
export declare function registeredDomainTimeoutsToTerraform(struct?: RegisteredDomainTimeouts | cdktf.IResolvable): any;
export declare function registeredDomainTimeoutsToHclTerraform(struct?: RegisteredDomainTimeouts | cdktf.IResolvable): any;
export declare class RegisteredDomainTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RegisteredDomainTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: RegisteredDomainTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/registered_domain dnsimple_registered_domain}
*/
export declare class RegisteredDomain extends cdktf.TerraformResource {
    static readonly tfResourceType = "dnsimple_registered_domain";
    /**
    * Generates CDKTF code for importing a RegisteredDomain resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RegisteredDomain to import
    * @param importFromId The id of the existing RegisteredDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/registered_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RegisteredDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/registered_domain dnsimple_registered_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RegisteredDomainConfig
    */
    constructor(scope: Construct, id: string, config: RegisteredDomainConfig);
    get accountId(): number;
    private _autoRenewEnabled?;
    get autoRenewEnabled(): boolean | cdktf.IResolvable;
    set autoRenewEnabled(value: boolean | cdktf.IResolvable);
    resetAutoRenewEnabled(): void;
    get autoRenewEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _contactId?;
    get contactId(): number;
    set contactId(value: number);
    get contactIdInput(): number | undefined;
    private _dnssecEnabled?;
    get dnssecEnabled(): boolean | cdktf.IResolvable;
    set dnssecEnabled(value: boolean | cdktf.IResolvable);
    resetDnssecEnabled(): void;
    get dnssecEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _domainRegistration;
    get domainRegistration(): RegisteredDomainDomainRegistrationOutputReference;
    get expiresAt(): string;
    private _extendedAttributes?;
    get extendedAttributes(): {
        [key: string]: string;
    };
    set extendedAttributes(value: {
        [key: string]: string;
    });
    resetExtendedAttributes(): void;
    get extendedAttributesInput(): {
        [key: string]: string;
    } | undefined;
    get id(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _premiumPrice?;
    get premiumPrice(): string;
    set premiumPrice(value: string);
    resetPremiumPrice(): void;
    get premiumPriceInput(): string | undefined;
    private _registrantChange;
    get registrantChange(): RegisteredDomainRegistrantChangeOutputReference;
    get state(): string;
    private _timeouts;
    get timeouts(): RegisteredDomainTimeoutsOutputReference;
    putTimeouts(value: RegisteredDomainTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | RegisteredDomainTimeouts | undefined;
    private _transferLockEnabled?;
    get transferLockEnabled(): boolean | cdktf.IResolvable;
    set transferLockEnabled(value: boolean | cdktf.IResolvable);
    resetTransferLockEnabled(): void;
    get transferLockEnabledInput(): boolean | cdktf.IResolvable | undefined;
    get unicodeName(): string;
    private _whoisPrivacyEnabled?;
    get whoisPrivacyEnabled(): boolean | cdktf.IResolvable;
    set whoisPrivacyEnabled(value: boolean | cdktf.IResolvable);
    resetWhoisPrivacyEnabled(): void;
    get whoisPrivacyEnabledInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
