/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface LetsEncryptCertificateConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/lets_encrypt_certificate#alternate_names LetsEncryptCertificate#alternate_names}
    */
    readonly alternateNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/lets_encrypt_certificate#auto_renew LetsEncryptCertificate#auto_renew}
    */
    readonly autoRenew: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/lets_encrypt_certificate#domain_id LetsEncryptCertificate#domain_id}
    */
    readonly domainId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/lets_encrypt_certificate#name LetsEncryptCertificate#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/lets_encrypt_certificate#signature_algorithm LetsEncryptCertificate#signature_algorithm}
    */
    readonly signatureAlgorithm?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/lets_encrypt_certificate dnsimple_lets_encrypt_certificate}
*/
export declare class LetsEncryptCertificate extends cdktf.TerraformResource {
    static readonly tfResourceType = "dnsimple_lets_encrypt_certificate";
    /**
    * Generates CDKTF code for importing a LetsEncryptCertificate resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LetsEncryptCertificate to import
    * @param importFromId The id of the existing LetsEncryptCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/lets_encrypt_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LetsEncryptCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/dnsimple/dnsimple/1.10.0/docs/resources/lets_encrypt_certificate dnsimple_lets_encrypt_certificate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LetsEncryptCertificateConfig
    */
    constructor(scope: Construct, id: string, config: LetsEncryptCertificateConfig);
    private _alternateNames?;
    get alternateNames(): string[];
    set alternateNames(value: string[]);
    resetAlternateNames(): void;
    get alternateNamesInput(): string[] | undefined;
    get authorityIdentifier(): string;
    private _autoRenew?;
    get autoRenew(): boolean | cdktf.IResolvable;
    set autoRenew(value: boolean | cdktf.IResolvable);
    get autoRenewInput(): boolean | cdktf.IResolvable | undefined;
    get createdAt(): string;
    get csr(): string;
    private _domainId?;
    get domainId(): string;
    set domainId(value: string);
    get domainIdInput(): string | undefined;
    get expiresAt(): string;
    get id(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _signatureAlgorithm?;
    get signatureAlgorithm(): string;
    set signatureAlgorithm(value: string);
    resetSignatureAlgorithm(): void;
    get signatureAlgorithmInput(): string | undefined;
    get state(): string;
    get updatedAt(): string;
    get years(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
